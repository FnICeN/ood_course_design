package com.Controller;

import com.Service.Impl.RelationsServiceImpl;
import com.Service.Impl.SpeaksServiceImpl;
import com.Service.RelationsService;
import com.Service.SpeaksService;
import com.pojo.Speaks;

import java.util.List;

public class GeneralController {
    RelationsService rsi = new RelationsServiceImpl();
    SpeaksService ssi = new SpeaksServiceImpl();
    public List<Speaks> getAllSpeaks() {
        return ssi.getAllSpeaks();
    }
}

package com.DAO;

import com.pojo.Relations;

import java.util.List;

public interface RelationsDAO {
    void addRelation(Relations relation);
    void delRelation(String content);
    List<Relations> getRelations(String query, Object... params);
}

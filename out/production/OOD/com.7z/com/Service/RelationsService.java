package com.Service;

import com.pojo.Relations;

public interface RelationsService {
    String getRelationsByContent(String content);
    void addRelationsBySpeakContent(String content, String[] relations);
}

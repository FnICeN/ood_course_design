package com.Service.Impl;

import com.DAO.BaseDAO;
import com.DAO.Impl.SpeaksDAOImpl;
import com.DAO.SpeaksDAO;
import com.Service.SpeaksService;
import com.pojo.Speaks;

import java.util.List;

public class SpeaksServiceImpl extends BaseDAO<Speaks> implements SpeaksService {
    private SpeaksDAO sdi = new SpeaksDAOImpl();

    @Override
    public void addSpeak(Speaks speak) {
        sdi.addSpeak(speak);
    }

    @Override
    public void delSpeakByObj(Speaks speak) {
        sdi.delSpeak(speak.getContent());
    }

    @Override
    public void reviseSpeak(Speaks s_before, Speaks s_after) {
        System.out.println("�޸�����...");
    }

    @Override
    public Speaks getSpeakByContent(String content) {
        return sdi.getSpeak(content);
    }

    @Override
    public List<Speaks> getAllSpeaks() {
        return sdi.getSpeaks("select * from cyberspeak");
    }
}

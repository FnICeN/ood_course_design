package com.Service;

import com.pojo.Speaks;

import java.util.List;

public interface SpeaksService {
    void addSpeak(Speaks speak);
    void delSpeakByObj(Speaks speak);
    void reviseSpeak(Speaks s_before, Speaks s_after);
    Speaks getSpeakByContent(String content);
    List<Speaks> getAllSpeaks();
}

package com.DAO;

import com.pojo.Speaks;

import java.util.List;

public interface SpeaksDAO {
    void addSpeak(Speaks speak);
    void delSpeak(String content);
    Speaks getSpeak(String content);
    List<Speaks> getSpeaks(String query, Object... params);
}
